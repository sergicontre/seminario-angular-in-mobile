var app = angular.module('myapp', []);

app.controller('MainCtrl', function($scope) {
  
});

app.directive('helloWorld',function(){
  return{
    scope:{
      color:'=',
      changeColor:'&',
    },
    restrict: 'E',
    replace: true,
    template: '<p style="background-color:{{color}}">Hello World</p>',
    link: function(scope,elem,attrs){

    }
  }
  
});