var app = angular.module('plunker', [ 'snap']);

app.controller('MainCtrl', function($scope, snapRemote) {
  $scope.name = 'I am mainCtrl';
  
  $scope.toggle = function(direction) {
    console.log('Direction:' + direction);
    snapRemote.toggle(direction);
  };
 
});
