For more Ionic Code Samples, please check out:
http://ionicframework.com/examples/code/