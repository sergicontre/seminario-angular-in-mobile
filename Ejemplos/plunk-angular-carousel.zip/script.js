// Code goes here

var app = angular.module('app', ['ui.bootstrap', 'angular-carousel']);

function MyController($scope, $http, $filter) {

  $scope.model = {
    pane1Elts : ['Pane1 - carousel 1', 'Pane1 - carousel 2', 'Pane1 - carousel 3', 'Pane1 - carousel 4'],
    pane2Elts : ['Pane2 - carousel 1', 'Pane2 - carousel 2', 'Pane2 - carousel 3', 'Pane2 - carousel 4'],
    show : false
  };

}

